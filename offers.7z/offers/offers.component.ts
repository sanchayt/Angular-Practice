import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {
  
  offers: any = {};
  categoryNames :string[] = [];
  allData: any = {};
  selectedCategoryName = '';
  sources = [ 'travel.html', 'tele.html', 'automobile.html', 'merch.html'];
  offerIndex = -1;
  categoryIndex = 0;
  srcFile = sources[0];
  
  
  constructor(private http: HttpClient) { }
  
//   configUrl = 'assets/config.json';

// getConfig() {
//   return this.http.get(this.configUrl);
// }

  ngOnInit() {
    //get the data
    this.http.get('../../assets/Offers/data/data.json')
    .subscribe(
      (result: any) => {

      this.allData = result;
        
      
      // selectedCategoryName = result.discounts
      console.log(this.allData.discounts);
      result.discounts.forEach(element => {
        //console.log(element.options);
        //console.log(element.CategoryName);
        this.categoryNames.push(element.CategoryName);
        if (element.CategoryName === 'Travel') {
          //console.log(element.options);
          this.offers = element.options;
          this.offerIndex = 0;
        }
      });

    });
  }

  changeCategory(category) {

    let currentOffersInCategory = {};
    this.allData.discounts.forEach((element, index) => {
        if (element.CategoryName === category) {
            currentOffersInCategory = element.options;
            this.offerIndex = 0;
            this.categoryIndex = index;
            console.log(this.categoryIndex);

        }
    });

    this.offers = currentOffersInCategory;
    this.srcFile = sources[this.categoryIndex]; 
    // _render()
  }
}
